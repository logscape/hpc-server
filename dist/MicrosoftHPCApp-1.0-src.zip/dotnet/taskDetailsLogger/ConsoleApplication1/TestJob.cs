﻿/*
 * Created by SharpDevelop.
 * User: gomoz
 * Date: 08/02/2012
 * Time: 09:03
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using NUnit.Framework;

namespace ConsoleApplication1
{
	[TestFixture]
	public class TestJob
	{
		[Test]
		public void TestMethod()
		{
			// TODO: Add your test.
		}
	}
}
