﻿/*
 * Created by SharpDevelop.
 * User: gomoz
 * Date: 08/02/2012
 * Time: 08:57
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using NUnit.Framework;

namespace ConsoleApplication1
{
	[TestFixture]
	public class TestJobCollection
	{
		[Test]
		public void TestMethod()
		{
			// TODO: Add your test.
		}
	}
}
